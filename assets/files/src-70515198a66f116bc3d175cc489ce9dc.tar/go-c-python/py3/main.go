package main

// 序言中还可以写 cgo 命令，比如下面让 cgo 使用 pkg-config 来寻找编译变量
// 只能用 import "C"，否则会被自动合并
// cgo 文档：https://pkg.go.dev/runtime/cgo

/*
#cgo pkg-config: python-3.10-embed
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdint.h>
*/
import "C"
import (
	"fmt"
)

func HighLevelCall() {
	// 处理入参
	// program := Py_DecodeLocale(argv[0], NULL)
	// if program == NULL {
	// 	fprintf(stderr, "Fatal error: cannot decode argv[0]\n")
	// 	exit(1)
	// }
	// defer PyMem_RawFree(program)
	// Py_SetProgramName(program) /* optional but recommended，向解释器告知 Python运行库的路径。 */

	// 初始化、扫尾
	C.Py_Initialize()
	defer C.Py_Finalize()

	// Py_GetVersion
	fmt.Println(C.GoString(C.Py_GetVersion()))

	// PyRun_SimpleString
	pycode1 := `
import sys
for path in sys.path:
  print(path)
`

	pycode2 := `
from time import time,ctime
print('Today is', ctime(time()))
`
	C.PyRun_SimpleString(C.CString(pycode1))
	C.PyRun_SimpleString(C.CString(pycode2))

	// PyRun_SimpleFile

}

func LowLevelCall() {

}

func main() {
	HighLevelCall()
	LowLevelCall()
}
