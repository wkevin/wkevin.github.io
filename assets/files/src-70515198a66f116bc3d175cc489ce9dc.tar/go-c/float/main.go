package main

// import "C" 上面的那句称为 “序言”，preamble，可以包含实际的 C 代码。导入后，我们可以通过“C”伪包来“跳转”到外部代码
// go build -x 可以跟踪 cgo 根据序言做了什么。

// #include <float.h>
import "C"
import "fmt"

func main() {
	fmt.Println("Max float value of float is", C.FLT_MAX)
}
