#!/bin/bash

find . -d -name "*" | xargs -I{} sh -c "cd {}; go build -x;cd .."