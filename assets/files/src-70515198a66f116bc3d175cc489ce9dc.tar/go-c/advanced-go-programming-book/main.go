package main

/*
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

int Add1(int param1, int param2) {
 return param1 + param2;
}
int Add2(unsigned int param1, int param2) {
 return param1 + param2;
}
double Add3(double param1, int param2) {
 return param1 + param2;
}

int SayHello(char* buff, int len) {
    char hello[] = "Hello Cgo!";
    int movnum = len < sizeof(hello) ? len:sizeof(hello);
    memcpy(buff, hello, movnum);
    return movnum;
}

char *SayHello2(char* buff, int len) {
    char hello[] = "Hello Cgo!";
    int movnum = len < sizeof(hello) ? len:sizeof(hello);
    memcpy(buff, hello, movnum);
		return buff;
}

struct Test {
    int a;
    float b;
    double type;
    int size:10;
    int arr1[10];
    int arr2[];
};
int Test_arr2_helper(struct Test * tm ,int pos){
    return tm->arr2[pos];
}

#pragma  pack(1)
struct Test2 {
    float a;
    char b;
    int c;
};

union USayHello {
 int Say;
 float Hello;
};
union USayHello init_usayhello(){
    union USayHello us;
    us.Say = 100;
    return us;
}
int USayHello_Say_helper(union USayHello * us){
    return us->Say;
}
*/
import "C"
import (
	"encoding/binary"
	"fmt"
	"unsafe"
)

func main() {
	// 数值类型转换——不怎么需要转换
	fmt.Println(C.Add1(1, 2))
	a := 1
	b := 2
	fmt.Println(C.Add2(C.uint(a), C.int(b))) // 使用变量，就必须 C.xxx 手动转换了
	fmt.Println(C.Add3(1, 2))

	// 切片的转换——传指针
	buff := make([]byte, 8)
	C.SayHello((*C.char)(unsafe.Pointer(&buff[0])), C.int(len(buff)))
	c := string(buff)
	fmt.Println(c) // 只有8个字符，Hello Cg，没有 Cgo

	// 字符串的转换 —— Go 的字符串并没有以'\0' 结尾
	//  C.CString()，它会在 C 内存空间内申请足够的空间，并将 Go 字符串拷贝到 C 空间中。
	// 因此 C.CString 申请的内存在 C 空间中，因此需要显式的调用 C.free 来释放空间
	// 因为涉及了一次从 Go 到 C 空间的内存拷贝，对于长字符串而言这会是难以忽视的开销。
	str := "abc"
	cstr := C.CString(str)             // cstr 为 *C.char
	defer C.free(unsafe.Pointer(cstr)) // 必须上面 #include <stdlib.h>
	fmt.Println(C.GoString(C.SayHello2(cstr, C.int(len(str)))))
	// str := "hello cgo"
	// cstr := C.CString(str)
	// C.output(cstr)
	// C.free(unsafe.Pointer(cstr))

	// struct 的转换
	test := C.struct_Test{} // 通过 C.struct_XXX 来访问 C 语言中 struct XXX 类型
	fmt.Println(test.a)
	fmt.Println(test.b)
	fmt.Println(test._type) // 结构体的成员名字中碰巧是 Go 语言的关键字，可以通过在成员名开头添加下划线来访问
	//fmt.Println(test.size)        // 位数据，位字段对应的成员无法在 Go 语言中访问
	fmt.Println(test.arr1[0])
	//fmt.Println(test.arr2)         // 零长数组无法直接访问，只能像下面掉 C 函数访问
	fmt.Println(C.Test_arr2_helper(&test, 1))

	test2 := C.struct_Test2{}
	test2.a = 99.0
	fmt.Println(test2.a)
	test2.b = 'h'
	fmt.Println(test2.b)
	// fmt.Println(test2.c) // 由于内存 1 字节对齐，该结构体部分字段Go无法访问

	// 联合
	// Go 语言中并不支持 C 语言联合类型，它们会被转为对应大小的字节数组。
	// 如果需要操作 C 语言的联合类型变量，一般有三种方法：
	// 第一种是在 C 语言中定义辅助函数；
	// 第二种是通过 Go 语言的"encoding/binary"手工解码成员(需要注意大端小端问题)；
	// 第三种是使用unsafe包强制转型为对应类型(这是性能最好的方式)。
	SayHello := C.init_usayhello()
	fmt.Println("C-helper ", C.USayHello_Say_helper(&SayHello)) // 1. 通过C辅助函数
	buf := C.GoBytes(unsafe.Pointer(&SayHello), 4)
	Say2 := binary.LittleEndian.Uint32(buf)
	fmt.Println("binary ", Say2)                                        // 2. 从内存直接解码一个int32
	fmt.Println("unsafe modify ", *(*C.int)(unsafe.Pointer(&SayHello))) // 3. 强制类型转换

	// 指针
	// C 和 Go 两个指针的类型完全一致则不需要转换可以直接通用
	// C 语言中，不同类型的指针是可以显式或隐式转换。
	// cgo 经常要面对的是 2 个完全不同类型的指针间的转换，实现这一转换的关键就是 unsafe.Pointer
}
