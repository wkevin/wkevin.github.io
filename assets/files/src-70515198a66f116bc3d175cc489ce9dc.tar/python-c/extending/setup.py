from distutils.core import setup, Extension

module1 = Extension('spammodule',
                    sources = ['spammodule.c'])

setup (name = 'spammodule.demo',
       version = '1.0',
       description = 'This is a demo package',
       ext_modules = [module1])