#!/bin/bash

pc=`pkg-config --cflags --libs python3-embed`
# pc=`/home/me/.pyenv/versions/3.9.13/bin/python3-config --cflags --ldflags --embed`
gcc main.c $pc -o demo # PASS
#gcc $pc main.c -o demo # Fail

# gcc `pkg-config --cflags python3-embed` main.c -c
# gcc main.o `pkg-config --libs python3-embed` -o demo # PASS
# gcc `pkg-config --libs python3-embed` main.o -o demo # Fail

if [ $? != 0 ];then
echo gcc $pc main.c -o demo
fi

if [ $? == 0 ];then
./demo
fi