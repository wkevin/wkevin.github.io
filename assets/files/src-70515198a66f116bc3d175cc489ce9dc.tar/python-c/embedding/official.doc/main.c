#define PY_SSIZE_T_CLEAN
#include <Python.h>

int HighLevel(int argc, char *argv[])
{
  wchar_t *program = Py_DecodeLocale(argv[0], NULL);
  if (program == NULL)
  {
    fprintf(stderr, "Fatal error: cannot decode argv[0]\n");
    exit(1);
  }
  Py_SetProgramName(program); /* optional but recommended */
  Py_Initialize();
  PyRun_SimpleString("from time import time,ctime\n"
                     "print('Today is', ctime(time()))\n");
  if (Py_FinalizeEx() < 0)
  {
    exit(120);
  }
  PyMem_RawFree(program);
  return 0;
}

int LowLevel(int argc, char *argv[])
{
  PyObject *pName, *pModule, *pFunc;
  PyObject *pArgs, *pValue;
  int i;

  if (argc < 3)
  {
    fprintf(stderr, "Usage: call pythonfile funcname [args]\n");
    return 1;
  }

  Py_Initialize();

  // 加载 argv[1] 指定的 Python 脚本
  pName = PyUnicode_DecodeFSDefault(argv[1]);
  /* Error checking of pName left out */
  PyRun_SimpleString("import sys");
  PyRun_SimpleString("sys.path.append('./')");
  pModule = PyImport_Import(pName);
  Py_DECREF(pName);

  if (pModule != NULL)
  {
    // 调用 argv[2] 指定的函数
    pFunc = PyObject_GetAttrString(pModule, argv[2]);
    /* pFunc is a new reference */

    if (pFunc && PyCallable_Check(pFunc))
    {
      // 创建一个元组
      pArgs = PyTuple_New(argc - 3);
      for (i = 0; i < argc - 3; ++i)
      {
        // 读取其余入参到元组
        pValue = PyLong_FromLong(atoi(argv[i + 3]));
        if (!pValue)
        {
          Py_DECREF(pArgs); // 引用减1
          Py_DECREF(pModule);
          fprintf(stderr, "Cannot convert argument\n");
          return 1;
        }
        /* pValue reference stolen here: */
        PyTuple_SetItem(pArgs, i, pValue);
      }
      // 执行函数，送入元组（入参）
      pValue = PyObject_CallObject(pFunc, pArgs);
      Py_DECREF(pArgs); // 减少引用，增加了2次，减少1次就可以了？
      if (pValue != NULL)
      {
        printf("Result of call: %ld\n", PyLong_AsLong(pValue));
        Py_DECREF(pValue);
      }
      else
      {
        Py_DECREF(pFunc);
        Py_DECREF(pModule);
        PyErr_Print();
        fprintf(stderr, "Call failed\n");
        return 1;
      }
    }
    else
    {
      if (PyErr_Occurred())
        PyErr_Print();
      fprintf(stderr, "Cannot find function \"%s\"\n", argv[2]);
    }
    Py_XDECREF(pFunc);
    Py_DECREF(pModule);
  }
  else
  {
    PyErr_Print();
    fprintf(stderr, "Failed to load \"%s\"\n", argv[1]);
    return 1;
  }
  if (Py_FinalizeEx() < 0)
  {
    return 120;
  }
  return 0;
}

int main(int argc, char *argv[])
{
  HighLevel(argc, argv);
  LowLevel(argc, argv);
}
