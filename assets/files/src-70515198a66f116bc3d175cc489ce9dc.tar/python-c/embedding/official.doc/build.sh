#!/bin/bash

gcc main.c `pkg-config --cflags --libs python3-embed` -o demo

if [ $? == 0 ];then
./demo multiply multiply 3 2
fi