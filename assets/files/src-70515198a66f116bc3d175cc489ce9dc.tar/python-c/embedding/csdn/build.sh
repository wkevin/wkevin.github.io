#!/bin/bash

gcc main.c `pkg-config --cflags --libs python3-embed` -o demo

if [ $? == 0 ];then
./demo 
fi