#include <stdio.h>
#include <Python.h>
int main()
{
  PyObject *pName, *pModule, *pDict, *pFunc;
  PyObject *pArgs, *pValue;
  //待传参数
  int time[6] = {1, 2, 3, 4, 5, 6};
  //初始化python
  Py_Initialize();
  // 检查初始化是否成功
  if (!Py_IsInitialized())
  {
    printf("初始化失败\n");
    Py_Finalize();
  }
  //设置python模块，搜寻位置，文件放在.c文件一起
  PyRun_SimpleString("import sys");
  PyRun_SimpleString("sys.path.append('./')");

  //获取python文件名，导入模块（我这里的py文件是graph.py）
  pModule = PyImport_ImportModule("graph");
  if (!pModule)
  {
    printf("py文件导入失败\n");
    Py_Finalize();
  }
  else
  {
    //直接获取模块中的函数
    pFunc = PyObject_GetAttrString(pModule, "create_graph");
    //验证函数是否获取成功
    if (!pFunc)
    {
      printf("函数导入失败\n");
      Py_Finalize();
    }

    //将c/c++类型数据转换为python类型，利用元组传递
    pArgs = PyTuple_New(6);
    pValue = PyLong_FromLong(time[0]);
    PyTuple_SetItem(pArgs, 0, pValue);

    pValue = PyLong_FromLong(time[1]);
    PyTuple_SetItem(pArgs, 1, pValue);

    pValue = PyLong_FromLong(time[2]);
    PyTuple_SetItem(pArgs, 2, pValue);

    pValue = PyLong_FromLong(time[3]);
    PyTuple_SetItem(pArgs, 3, pValue);

    pValue = PyLong_FromLong(time[4]);
    PyTuple_SetItem(pArgs, 4, pValue);

    pValue = PyLong_FromLong(time[5]);
    PyTuple_SetItem(pArgs, 5, pValue);

    //调用直接获得的函数，并传递参数
    pValue = PyObject_CallObject(pFunc, pArgs);

    //释放python
    Py_Finalize();

    printf("success");
    return 0;
  }
}
